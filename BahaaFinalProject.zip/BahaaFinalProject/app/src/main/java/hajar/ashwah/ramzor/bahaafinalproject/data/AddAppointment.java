package hajar.ashwah.ramzor.bahaafinalproject.data;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;

import com.google.android.material.textfield.TextInputEditText;

import hajar.ashwah.ramzor.bahaafinalproject.R;

public class AddAppointment extends AppCompatActivity
{
    private EditText etTime2;
    private EditText etDate;
    private TextInputEditText etFullName;
    private TextInputEditText etPhone;
    private TextInputEditText etCondition;
    private SeekBar seekBar;
    private Button btnCancel;
    private Button btnSave;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_appointment);
        etTime2=findViewById(R.id.etTime2);
        etDate=findViewById(R.id.etDate);
        etFullName=findViewById(R.id.etFullName);
        etPhone=findViewById(R.id.etPhone);
        etCondition=findViewById(R.id.etCondition);
        seekBar=findViewById(R.id.seekBar);
        btnCancel=findViewById(R.id.btncancel);
        btnSave=findViewById(R.id.btnSave);



    }
}